import java.lang.Thread;

public class Roll0917{

	public static void main(String []args){
       
        
       Thread A = new Thread(new Runnable(){
           public void run(){
                for(int i=0; i<50; i++){
                    System.out.println("Thread A: "+i);
                
                }
           }
           
        });
        
        A.start();
        
        Thread B = new Thread(new Runnable(){
           public void run(){
                for(int i=0; i<50; i++){
                    System.out.println("Thread B: "+i);
                
                }
           }
        });
        B.start();
        
        Thread C = new Thread(new Runnable(){
         public void run(){
                for(int i=0; i<50; i++){
                    System.out.println("Thread C: "+i);
                
                }
           }
        });
        C.start();
        
        

	}

} 
