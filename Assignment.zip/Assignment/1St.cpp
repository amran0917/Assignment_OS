#include<bits/stdc++.h>

using namespace std;

struct my_process
{
    char p_name;
    int b_time;
}process ;


int first_come_first_serve(vector<my_process> &vec,int n_input)
{
    cout<<"#######FirsT Come Firs Serve####"<<endl;
    cout<<"Process List" << endl;
    for (int i=0;i<n_input;i++)
    {
        cout<<vec[i].p_name<<endl;

    }
}
int main()
{

    int n_input;
    cout<<"Enter your input:" << endl;
    cin>>n_input;

    vector<my_process>vec;


    cout<<"Enter process_name and burst_time and priority" <<endl;
    char ch,b;
    for(int i=0;i<n_input;i++)
    {
        cin>>ch>>b;
        process.p_name = ch;
        process.b_time =b;

         vec.push_back(process);
    }

    first_come_first_serve(vec,n_input);
}
