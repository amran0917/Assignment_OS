#include<bits/stdc++.h>
using namespace std;

int main()
{
    int no_resource,process_no,c=0;

    cout<<"Enter the number of  resource And Process number :" <<endl;
    cin>>no_resource>>process_no;

    int allocation[process_no][no_resource],maX[process_no][no_resource],available[no_resource],need[process_no][no_resource],seqS[process_no];

    //Allocation
    cout<<"Allocation:"<<endl;
    for(int i=0;i<process_no;i++)
    {
        for(int j=0;j<no_resource;j++)
        {
            cin>>allocation[i][j];
        }

    }
    cout<<endl;

    //maxmium

    cout<<"maximum:"<<endl;

     for(int i=0;i<process_no;i++)
    {
        for(int j=0;j<no_resource;j++)
        {
            cin>>maX[i][j];
        }

    }

    cout<<endl;

    cout<<"available:"<<endl; //available resource
    for(int i=0;i<no_resource;i++)
    {
        cin>>available[i];

    }

    cout<<"Need:"<<endl; // need resource

    for(int i=0;i<process_no;i++)
    {
        for(int j=0;j<no_resource;j++)
        {
            need[i][j] = maX[i][j] - allocation[i][j];
            cout<<need[i][j] << endl;
        }
        cout<<endl;
    }

     cout<<endl;
     int flag=0;
     int s=0,temp=0;
     int p=0,complete[process_no]={0};

    int processRemaining = process_no;
    while(processRemaining>0)
    {
        c = 0;
         temp=processRemaining;
        for(int i=0;i<process_no;i++)
        {
            flag=0;
             c++;
             p=i;
            if(complete[i]==0)
            {
                for(int j=0;j<no_resource;j++)
                {

                    if(available[j]<need[i][j])
                    {
                        // cout<<"unsafe state is p" << c <<endl;
                        flag=0;
                        break;

                    }

                    else
                        {
                                flag=1;

                        }
                }

            }

            if(flag==1)
            {
                    cout<<"Process is safe p:"<<c<<endl;
                    temp--;

                    for(int j=0;j<no_resource;j++)
                    {
                        available[j]+=allocation[p][j];
                        complete[p] =1;

                    }
            }
        }




        if(temp == processRemaining)
        {
            cout<<"Deadlock " <<endl;
            return 0;

        }
        else
            processRemaining = temp;

    }


    return 0;
}
