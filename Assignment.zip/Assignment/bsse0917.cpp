#include<bits/stdc++.h>

using namespace std;

struct my_process
{
    char p_name;
    int a_time;
    int b_time;
    int prio;
}process ;

bool compare2(my_process &x,my_process &y)
{
    return x.b_time<y.b_time;
}

bool compare(my_process &p,my_process &q)
{
    return p.prio>q.prio;
}

int turnAround(vector<my_process>&vec,int n_input,int *wait)
{
    int turn[n_input];

    for(int i=0;i<n_input;i++)
    {
        turn[i]= wait[i]+vec[i].b_time;
    }

    cout<<"Turn around TIme" << endl;

    for(int i=0;i<n_input;i++)
    {
        cout<<turn[i]<<endl;
    }
}

int waiting_time(vector<my_process> &vec,int n_input)
{
    int wait[n_input];
    wait[0] = 0;

    for(int i=1;i<n_input;i++)
    {
        wait[i] = vec[i-1].b_time+wait[i-1];
    }
    cout<<"WaitingTime" <<endl;
    for(int i=0;i<n_input;i++)
    {
        cout<<wait[i]<<endl;
    }

     turnAround(vec,n_input,wait);
}
int first_come_first_serve(vector<my_process> &vec,int n_input)
{
    cout<<"#######Firs Come Firs Serve####"<<endl;
    cout<<"Process List" << endl;
    for (int i=0;i<vec.size();i++)   // vec.size() not working use n_input instead
    {
        cout<<vec[i].p_name<<endl;

    }

    waiting_time(vec,n_input);
}

int priority_based(vector<my_process>&vec,int n_input)
{
    cout<< "#####Priority Based####"<<endl;
    sort(vec.begin(),vec.end(),compare);
    cout<<"Process List" << endl;
     for (int i=0;i<vec.size();i++)
    {
        cout<<vec[i].p_name<<endl;

    }
    waiting_time(vec,n_input);
}

int  shortest_job_first(vector<my_process>&vec,int n_input)
{
    cout<<"####Shortest JOb scheduling######"<<endl;
    sort(vec.begin(),vec.end(),compare2);
    cout<<"Process List" << endl;
     for (int i=0;i<vec.size();i++)
    {
        cout<<vec[i].p_name<<endl;

    }
    waiting_time(vec,n_input);
}

  int round_robin(vector<my_process>&vec,int n_input)
  {
      cout<<"####Round-robin-algo####"<<endl;
      cout<<"ENter the time slice"<<endl;
      int time_slice,total;
      cin>>time_slice;

      int r_time[n_input];

      cout<<"Process level"<<endl;

      for(int i=0;i<n_input;i++)
      {
          r_time[i] = vec[i].b_time;

          if(r_time[i]<=time_slice &&r_time[i]!=0)
          {
              total+=r_time[i];
              r_time[i]=0;
          }

          else if(r_time[i]>time_slice)
          {
              r_time[i] = r_time[i]-time_slice;
              total = total+time_slice;
          }

      }

       for (int i=0;i<vec.size();i++)
    {
        cout<<vec[i].p_name<<endl;

    }
  }
int main()
{
    vector<my_process> vec;

    int n_input;
    char ch;
    int b;

    cout<<"Enter ur input" << endl;
    cin>>n_input;


    cout<<"Enter process_name ,Arrival_time and burst_time and priority" <<endl;
    for(int i=0;i<n_input;i++)
    {
        cin>>ch;
        cin>>b>>process.prio>>process.a_time;
        process.p_name = ch;
        process.b_time =b;

         vec.push_back(process);
    }
       // first_come_first_serve(vec,n_input);
        priority_based(vec,n_input);
      // shortest_job_first(vec,n_input);
      // round_robin(vec,n_input);


    return 0;
}
